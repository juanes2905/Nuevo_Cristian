const express = require('express')
const router = express.Router()
const userModel = require ('../models/userModels')
const userModels = require('../models/userModels')

router.post('/register', 
            async(req, res)=>{
                try {
                    const user = 
                    await userModels.
                            create({
                                name,
                                email,
                                role,
                                password
                            }
                            )
            res
                .status(201)
                .json({
                    sucess: true,
                    msg: "user successflully registered",
                    token: user.ObtenerJWT()
                })
                } catch (error) {
                    res
                        .status(400)
                        .json({
                            sucess: false,
                            message: error.message
                        })
                    
                }

            })

router.post('/login',
 async (req , res) => {
    //desestructuracion:
    //- objetos
    //- arreglos
    const{ email, password} =req.body;

      if(!email || !password){
        res.
        status(400).
        json({
            sucess: false,
            message: "debe ingresar email o password"
        })
      }else{
        try {
            //encontrar usuario que tenga el password que tenga el email
            const user = await userModels.findOne({email}).select("+password")
            if(!user){
                res.
                status(400).
                json({sucess: false, 
                    msg: "no se encontro el usuario"
                })
            }else{
                //utilizar el metodo de comparar el email
                const isMatch = await user.comparePassword(password)
                if(!isMatch){
                    res.status(400).json({
                        sucess: false,
                        msg: "Contraseña incorrecta"
                    })
                }else{
                    res.status(200).json({
                        sucess: true,
                        msg: "Login correcto",
                        token: user.ObtenerJWT()

                    })
                    }
                }
            
        } catch (error) {
            
        }
      }

 })



module.exports = router